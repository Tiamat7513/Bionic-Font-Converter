document.addEventListener('DOMContentLoaded', () => {
    const inputText = document.getElementById('inputText');
    const convertButton = document.getElementById('convertButton');
    const outputText = document.getElementById('outputText');
    const contextMenu = document.getElementById('contextMenu');
    const copyText = document.getElementById('copyText');
    const pasteText = document.getElementById('pasteText');

    function convertToBionic() {
        const words = inputText.value.split(' ');

        const bionicText = words.map(word => {
            const mid = Math.ceil(word.length / 2);
            return `<span class="bold">${word.substring(0, mid)}</span>${word.substring(mid)}`;
        }).join(' ');

        outputText.innerHTML = bionicText;
    }

    convertButton.addEventListener('click', convertToBionic);

    inputText.addEventListener('keypress', (event) => {
        if (event.key === 'Enter') {
            event.preventDefault(); // Prevents the default action of adding a new line
            convertToBionic();
        }
    })})
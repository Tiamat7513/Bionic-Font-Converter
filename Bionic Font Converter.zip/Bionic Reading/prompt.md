Prompts typed into copilot to make a bionic converter:
(Colour theme seleceted manually)

1. Help me code the html, css and script for bionic font.

2. Update the previous html, css and script to make a bionic font converter with an input field and an ouput field.
3. Improve the layout of the webpage to be more reader /user friendly and have colours that are gentle on the eyes of those that read frequently for long hours.

4. How do I code to allow for the enter button being pressed to conver the bionic font.
